# Khánh Floral — Website bán hoa tươi

Bản làm mới giao diện dựa trên đặc tả trong `Hoc_Web/du-an-web/DAC_TA.md` của file gốc. Dự án dùng HTML, CSS và JavaScript thuần, không cần framework hoặc công cụ build.

## Cấu trúc

- `public/index.html`: Trang chủ, banner, sản phẩm nổi bật, giới thiệu tiệm và đăng ký nhận tin.
- `public/products.html`: Danh sách 8 mẫu hoa, tìm kiếm, lọc theo chủ đề và sắp xếp theo giá/tên.
- `public/detail.html`: Trang chi tiết sản phẩm, chọn kích cỡ, số lượng và lời nhắn đính kèm.
- `public/contact.html`: Thông tin liên hệ, biểu mẫu liên hệ và hướng dẫn giao hoa.
- `public/css/style.css`: Giao diện responsive cho máy tính, tablet và điện thoại.
- `public/js/app.js`: Menu điện thoại, giỏ hàng demo lưu bằng localStorage, lọc sản phẩm và xử lý biểu mẫu demo.

## Chạy thử

1. Giải nén thư mục `Khanhbanhang-redesign.zip`.
2. Mở thư mục `Khánhbanhang` trong VS Code.
3. Mở `public/index.html` bằng trình duyệt hoặc dùng tiện ích Live Server.
4. Dùng menu để chuyển qua bốn trang. Thử thêm hoa vào túi, tìm kiếm/lọc sản phẩm và thay đổi số lượng ở trang chi tiết.

## Lưu ý

- Ảnh minh họa và font chữ tải từ Internet, nên cần kết nối mạng để hiển thị đầy đủ.
- Giỏ hàng chỉ là chức năng demo ở phía trình duyệt; chưa có thanh toán, quản trị đơn hàng hay cơ sở dữ liệu.
- Biểu mẫu chỉ hiện thông báo demo và chưa gửi dữ liệu đến máy chủ.
- Tên, địa chỉ, số điện thoại và giá trong bản demo là nội dung minh họa; hãy thay bằng thông tin được phép sử dụng trước khi nộp hoặc triển khai thật.

## Đối chiếu đề bài gốc

Đặc tả tham khảo được lưu ở `docs/DAC_TA-tham-khao.md`. Trong file RAR ban đầu, `detail.html` và `contact.html` chưa có ở thư mục `public`; hai trang này đã được bổ sung theo đặc tả. Các chức năng backend Express/EJS được nhắc trong ghi chú bối cảnh không nằm trong phần mã được cung cấp, nên bản này hoàn thiện phần giao diện tĩnh trước.
