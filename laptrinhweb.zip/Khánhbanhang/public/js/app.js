'use strict';

const FLOWERS = {
  rose: { name: 'Nàng thơ tháng Sáu', price: 450000, image: 'https://images.unsplash.com/photo-1548586196-aa5803b77379?auto=format&fit=crop&w=1100&q=85', category: 'THE LOVE COLLECTION', description: 'Hoa hồng đỏ tuyển chọn kết hợp cùng lá xanh dịu mắt, được bó thủ công bằng giấy gói tối giản. Một lời thương chân thành dành cho người đặc biệt.' },
  sunflower: { name: 'Nắng trong vườn', price: 390000, image: 'https://images.unsplash.com/photo-1597848212624-e6f2d7a8d9d1?auto=format&fit=crop&w=1100&q=85', category: 'THE HAPPY COLLECTION', description: 'Những đóa hướng dương rạng rỡ mang theo lời chúc tích cực, phù hợp cho sinh nhật, khai trương hoặc một ngày cần thêm nắng.' },
  baby: { name: 'Mây trắng dịu êm', price: 320000, image: 'https://images.unsplash.com/photo-1494972308805-463bc619d34e?auto=format&fit=crop&w=1100&q=85', category: 'THE SOFT COLLECTION', description: 'Sắc trắng tinh khôi và dáng bó tự nhiên tạo nên món quà nhẹ nhàng cho những dịp bạn muốn gửi lời quan tâm.' },
  tulip: { name: 'Hẹn nhau mùa tulip', price: 520000, image: 'https://images.unsplash.com/photo-1528913775512-624d24b27b96?auto=format&fit=crop&w=1100&q=85', category: 'THE TULIP COLLECTION', description: 'Tulip thanh lịch với gam màu dịu dàng, dành cho những cuộc hẹn đáng nhớ và lời nhắn được giữ riêng cho hai người.' },
  daisy: { name: 'Bình minh dịu ngọt', price: 280000, image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=1100&q=85', category: 'THE BIRTHDAY COLLECTION', description: 'Bó hoa tươi vui, nhỏ xinh với sắc màu pastel, mang đến cảm giác ấm áp như một buổi sáng đầy nắng.' },
  orchid: { name: 'Lời chúc thịnh vượng', price: 650000, image: 'https://images.unsplash.com/photo-1566907225472-514f9c9e5c98?auto=format&fit=crop&w=1100&q=85', category: 'THE CELEBRATION COLLECTION', description: 'Thiết kế hoa lan trang nhã, thích hợp làm quà chúc mừng khai trương, sự kiện hoặc gửi lời chúc thành công.' },
  pink: { name: 'Hồng phấn thì thầm', price: 420000, image: 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?auto=format&fit=crop&w=1100&q=85', category: 'THE LOVE COLLECTION', description: 'Hoa hồng phấn mềm mại dành cho những lời thương chưa cần nói thành câu, được gói theo phong cách tối giản.' },
  summer: { name: 'Mùa hè rực rỡ', price: 480000, image: 'https://images.unsplash.com/photo-1525310072745-f49212b5ac6d?auto=format&fit=crop&w=1100&q=85', category: 'THE HAPPY COLLECTION', description: 'Bó hoa phối nhiều sắc độ tươi sáng, thích hợp chúc mừng một cột mốc mới hoặc làm ngày thường thêm rộn ràng.' }
};

const money = value => new Intl.NumberFormat('vi-VN').format(value) + 'đ';
function readCart() {
  try { return JSON.parse(localStorage.getItem('khanhFloralCart') || '{}'); }
  catch { return {}; }
}
function saveCart(cart) {
  try { localStorage.setItem('khanhFloralCart', JSON.stringify(cart)); } catch { /* Storage may be unavailable in private browsing. */ }
  updateCartCount(cart);
}
function updateCartCount(cart = readCart()) {
  const count = Object.values(cart).reduce((total, item) => total + Number(item.quantity || 0), 0);
  document.querySelectorAll('.cart-count').forEach(node => { node.textContent = count; });
}
function addToCart(id, quantity = 1, extra = {}) {
  const flower = FLOWERS[id];
  if (!flower) return;
  const cart = readCart();
  if (!cart[id]) cart[id] = { name: flower.name, price: flower.price, quantity: 0, note: '' };
  cart[id].quantity += quantity;
  if (extra.price) cart[id].price = flower.price + extra.price;
  if (extra.note) cart[id].note = extra.note;
  saveCart(cart);
  showToast(`Đã thêm “${flower.name}” vào túi hoa.`);
}
function showToast(message) {
  let toast = document.querySelector('.site-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'site-toast';
    toast.setAttribute('role', 'status');
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('visible');
  window.clearTimeout(showToast.timeout);
  showToast.timeout = window.setTimeout(() => toast.classList.remove('visible'), 2600);
}

// Mobile navigation
const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');
if (menuToggle && mainNav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = mainNav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.textContent = isOpen ? '×' : '☰';
  });
}

// Quick-add buttons are intentionally buttons inside product links; prevent accidental navigation.
document.querySelectorAll('[data-add]').forEach(button => {
  button.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    if (button.id === 'add-detail') {
      const quantity = Number(document.querySelector('#quantity')?.textContent || 1);
      const selectedSize = Number(document.querySelector('input[name="size"]:checked')?.value || 0);
      const note = document.querySelector('#gift-note')?.value.trim() || '';
      addToCart(button.dataset.add, quantity, { price: selectedSize, note });
    } else {
      addToCart(button.dataset.add);
    }
  });
});
updateCartCount();

// Product catalog search, topic filters, sorting and query-string deep links.
const catalogGrid = document.querySelector('#catalog-grid');
if (catalogGrid) {
  const cards = Array.from(catalogGrid.querySelectorAll('.product-card'));
  const searchInput = document.querySelector('#product-search');
  const sortSelect = document.querySelector('#product-sort');
  const countLabel = document.querySelector('#catalog-count');
  const emptyState = document.querySelector('#empty-state');
  let activeCategory = 'all';
  const params = new URLSearchParams(window.location.search);
  const categoryParam = params.get('category');
  if (['love', 'birthday', 'congrats', 'gentle'].includes(categoryParam)) activeCategory = categoryParam;
  document.querySelectorAll('[data-filter]').forEach(button => button.classList.toggle('active', button.dataset.filter === activeCategory));
  function renderCatalog() {
    const term = (searchInput?.value || '').trim().toLocaleLowerCase('vi');
    const visible = cards.filter(card => {
      const matchesName = card.dataset.name.toLocaleLowerCase('vi').includes(term);
      const categories = card.dataset.category.split(' ');
      return matchesName && (activeCategory === 'all' || categories.includes(activeCategory));
    });
    const sort = sortSelect?.value || 'featured';
    visible.sort((a, b) => {
      if (sort === 'low') return Number(a.dataset.price) - Number(b.dataset.price);
      if (sort === 'high') return Number(b.dataset.price) - Number(a.dataset.price);
      if (sort === 'name') return a.dataset.name.localeCompare(b.dataset.name, 'vi');
      return cards.indexOf(a) - cards.indexOf(b);
    });
    cards.forEach(card => { card.hidden = !visible.includes(card); });
    visible.forEach(card => catalogGrid.appendChild(card));
    if (countLabel) countLabel.textContent = `Đang hiển thị ${visible.length} mẫu hoa`;
    if (emptyState) emptyState.hidden = visible.length !== 0;
  }
  document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => {
    activeCategory = button.dataset.filter;
    document.querySelectorAll('[data-filter]').forEach(item => item.classList.toggle('active', item === button));
    renderCatalog();
  }));
  searchInput?.addEventListener('input', renderCatalog);
  sortSelect?.addEventListener('change', renderCatalog);
  renderCatalog();
}

// Detail page reads the chosen product from the URL.
const detailName = document.querySelector('#detail-name');
if (detailName) {
  const id = new URLSearchParams(window.location.search).get('product') || 'rose';
  const flower = FLOWERS[id] || FLOWERS.rose;
  const image = document.querySelector('#detail-image');
  const category = document.querySelector('#detail-category');
  const price = document.querySelector('#detail-price');
  const description = document.querySelector('#detail-description');
  const addButton = document.querySelector('#add-detail');
  detailName.textContent = flower.name;
  if (image) { image.src = flower.image; image.alt = flower.name; }
  if (category) category.textContent = flower.category;
  if (price) price.textContent = money(flower.price);
  if (description) description.textContent = flower.description;
  if (addButton) addButton.dataset.add = id in FLOWERS ? id : 'rose';
  let quantity = 1;
  const output = document.querySelector('#quantity');
  document.querySelector('#qty-minus')?.addEventListener('click', () => { quantity = Math.max(1, quantity - 1); if (output) output.textContent = quantity; });
  document.querySelector('#qty-plus')?.addEventListener('click', () => { quantity = Math.min(20, quantity + 1); if (output) output.textContent = quantity; });
}

// Demo forms: show clear feedback without pretending data has been sent to a server.
document.querySelectorAll('.newsletter-form').forEach(form => form.addEventListener('submit', event => {
  event.preventDefault();
  const message = form.querySelector('.form-message');
  if (message) message.textContent = 'Cảm ơn bạn! Đây là bản demo nên email chưa được gửi lên máy chủ.';
  form.reset();
}));
const contactForm = document.querySelector('#contact-form');
if (contactForm) contactForm.addEventListener('submit', event => {
  event.preventDefault();
  const message = contactForm.querySelector('.form-message');
  if (message) message.textContent = 'Cảm ơn bạn đã để lại lời nhắn. Bản demo chưa gửi dữ liệu đến cửa hàng thật.';
  contactForm.reset();
});
