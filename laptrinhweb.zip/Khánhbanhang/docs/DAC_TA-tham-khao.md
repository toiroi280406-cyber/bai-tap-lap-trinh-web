# BẢN ĐẶC TẢ WEBSITE:SHOP HOA TƯƠI TRỰC TUYẾN

## 1. Tên website và mục đích
Tên website: Khánhbanhang - Shop Hoa Tươi Trực Tuyến

Mục đích: Giới thiệu cửa hàng, trưng bày các mẫu hoa tươi (hoa sinh nhật, hoa khai trương, hoa tình yêu,...) và hỗ trợ khách hàng đặt hoa trực tuyến nhanh chóng, tiện lợi.

## 2. Đối tượng người dùng
Khách hàng cá nhân: Bạn trẻ, người đi làm có nhu cầu mua hoa tặng người yêu, người thân, bạn bè nhân dịp sinh nhật, kỷ niệm, lễ tết.

Khách hàng doanh nghiệp/đoàn thể: Các công ty, văn phòng cần đặt hoa chúc mừng khai trương, sự kiện hoặc các dịp lễ của doanh nghiệp.

## 3. Bảng danh sách 
Tên trang Tên file Nội dung chính:
Trang chủ index.html Banner giới thiệu, mẫu hoa nổi bật và bán chạy.
Sản phẩm products.htmlDanh sách tất cả các mẫu hoa và bộ lọc theo chủ đề.
Chi tiết detail.htmlẢnh hoa lớn, giá tiền, thông tin chi tiết và nút mua.
Liên hệ contact.htmlForm gửi câu hỏi, địa chỉ shop và bản đồ.

## 4. Bố cục chung (Header, Menu, Footer)
Đầu trang (Header): Logo "Khánhbanhang", thanh tìm kiếm sản phẩm nhanh, hotline hỗ trợ, biểu tượng giỏ hàng.

Thanh điều hướng (Menu): Cố định ở đầu trang, chứa đường dẫn liên kết đến 4 trang: Trang chủ, Sản phẩm, Chi tiết, Liên hệ.

Chân trang (Footer): Thông tin bản quyền, địa chỉ cửa hàng, thời gian hoạt động, liên kết mạng xã hội (Facebook, Zalo, Instagram) và chính sách giao hoa.

## 5. Phong cách thiết kế
Màu sắc chủ đạo:

Màu chính: Hồng pastel nhẹ nhàng (#E88D72 hoặc #F4A261) kết hợp Đỏ hoa tươi (#E63946) tạo điểm nhấn.

Màu nền: Trắng / Kem nhạt (#FAFAFA) giúp tôn lên màu sắc tự nhiên của các bông hoa.

Màu chữ: Xám đậm (#2B2B2B) giúp dễ đọc, không bị chói mắt.

Phông chữ: Sử dụng phông chữ không chân hiện đại, thanh lịch như Roboto hoặc Open Sans.

## 6. Yêu cầu hiển thị trên điện thoại (Responsive)
Tự động co giãn phù hợp với các kích thước màn hình (Desktop, Tablet, Mobile).

Trên điện thoại:

Thanh menu tự động gập gọn thành nút 3 gạch (Hamburger Menu).

Danh sách sản phẩm chuyển thành dạng 1 hoặc 2 cột để không bị chèn ép hình ảnh.

Nút gọi điện / nhắn Zalo luôn hiển thị góc dưới màn hình để khách hàng bấm mua nhanh.